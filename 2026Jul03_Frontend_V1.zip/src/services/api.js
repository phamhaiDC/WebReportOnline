import axios from 'axios';

const api = axios.create({
    baseURL: `${window.location.protocol}//${window.location.hostname}:5577/api`,
});

export const getReports = async () => {
    const response = await api.get('/reports');
    return response.data;
};

export const getReportDetails = async (id, params = {}) => {
    const response = await api.post(`/reports/${id}`, params);
    return response.data;
};

export const login = async (email, password) => {
    const response = await api.post('/auth/login', { email, password });
    return response.data;
};

export const rollCall = () => {
    // Keep alive or check connection
    return api.get('/');
};

export const getHealthCheckInstances = () => api.get('/healthcheck/instances').then(r => r.data);

export const runHealthCheck = (instanceKey, sections) =>
    api.post('/healthcheck/run', { instanceKey, sections }).then(r => r.data);

export const getConnectionsMonitorRoots = () =>
    api.get('/reports/connections-monitor/roots').then(r => r.data);

export const runConnectionsMonitor = (rootNetworkName, maxDepth) =>
    api.post('/reports/connections-monitor/run', { rootNetworkName, maxDepth }).then(r => r.data);

export default api;
