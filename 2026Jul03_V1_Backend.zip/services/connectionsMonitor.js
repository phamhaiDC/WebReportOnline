'use strict';

// Đọc/parse trang /Connects của server RK7 (Reference Server hoặc Report Server)
// và dựng cây kết nối đệ quy. Nguồn cấu hình: config/connection_check_sources.json —
// file đó chứa IP/thông tin nội bộ thật, không copy nguyên văn sang tài liệu/project khác.

const axios = require('axios');
const cheerio = require('cheerio');
const https = require('https');

const DEFAULT_MAX_DEPTH = 6;
const REQUEST_TIMEOUT_MS = 10000;

const agent = new https.Agent({ rejectUnauthorized: false });

// Ví dụ header thật: Reports Server 'VTI_REF_PROD' (PID: 13524, Version: 7.25.12 003 release)
const HEADER_RE = /Reports Server '(.+?)' \(PID: (\d+), Version: (.+?)\)/;

function parseConnectsHtml(html) {
  const $ = cheerio.load(html);
  const bodyText = $('body').text();
  const headerMatch = bodyText.match(HEADER_RE);
  const serverInfo = headerMatch
    ? { networkName: headerMatch[1], pid: headerMatch[2], version: headerMatch[3].trim() }
    : { networkName: null, pid: null, version: null };

  const connects = [];
  $('table tr').each((_, el) => {
    const tds = $(el).find('td');
    if (tds.length < 5) return;
    const networkName = $(tds[0]).text().trim();
    if (!networkName || networkName === 'NetworkNameText') return; // header row
    connects.push({
      networkName,
      remoteIp: $(tds[1]).text().trim(),
      additionalInfo: $(tds[2]).text().trim(),
      applicationKind: $(tds[3]).text().trim(),
      applicationVer: $(tds[4]).text().trim(),
    });
  });

  return { serverInfo, connects };
}

async function fetchConnects(entry) {
  const url = `https://${entry.ip}:${entry.port}/Connects`;
  const auth = Buffer.from(`${entry.user}:${entry.pass}`).toString('base64');
  const response = await axios.get(url, {
    headers: { Authorization: `Basic ${auth}` },
    httpsAgent: agent,
    timeout: REQUEST_TIMEOUT_MS,
  });
  return parseConnectsHtml(response.data);
}

// Duyệt cây tuần tự (không song song) để tránh dồn tải lên server RK7 production,
// cùng tinh thần với health-check engine hiện có (chạy tuần tự từng câu SQL).
// Nếu sau này cần tăng tốc, có thể đổi các vòng for-of dưới đây thành Promise.all
// theo từng tầng, kèm giới hạn concurrency (semaphore) để không làm sập server thật.
async function buildChildNode(connect, depth, maxDepth, visited, sourcesByName) {
  const base = {
    networkName: connect.networkName,
    remoteIp: connect.remoteIp,
    additionalInfo: connect.additionalInfo,
    applicationKind: connect.applicationKind,
    applicationVer: connect.applicationVer,
  };

  if (connect.applicationKind !== 'Report Server') {
    // Manager Station / Cash Server / bất kỳ giá trị lạ nào khác đều là leaf, không mở rộng.
    return { ...base, status: 'leaf', children: [] };
  }

  const entry = sourcesByName.get(connect.networkName);
  if (!entry) {
    return { ...base, status: 'no_config', children: [] };
  }

  const key = `${entry.ip}:${entry.port}`;

  // Check visited BEFORE depth: a node we've already seen is always a genuine
  // cycle (regardless of depth), while max_depth_reached must only ever apply
  // to a node's first appearance — this keeps the two statuses mutually
  // exclusive so summary counts never double-count or drop a real connection.
  if (visited.has(key)) {
    return { ...base, status: 'cycle_detected', ip: entry.ip, port: entry.port, children: [] };
  }

  if (depth >= maxDepth) {
    return { ...base, status: 'max_depth_reached', ip: entry.ip, port: entry.port, children: [] };
  }

  visited.add(key);

  try {
    const { serverInfo, connects } = await fetchConnects(entry);
    const children = [];
    for (const child of connects) {
      children.push(await buildChildNode(child, depth + 1, maxDepth, visited, sourcesByName));
    }
    return {
      ...base,
      status: 'expanded',
      ip: entry.ip,
      port: entry.port,
      pid: serverInfo.pid,
      version: serverInfo.version,
      children,
    };
  } catch (err) {
    return {
      ...base,
      status: 'unreachable',
      ip: entry.ip,
      port: entry.port,
      error: err.message || String(err),
      children: [],
    };
  }
}

async function buildTree(rootEntry, maxDepth, sourcesByName) {
  const depth = Number.isInteger(maxDepth) && maxDepth > 0 ? maxDepth : DEFAULT_MAX_DEPTH;
  const visited = new Set([`${rootEntry.ip}:${rootEntry.port}`]);

  const rootBase = {
    networkName: rootEntry.networkName,
    ip: rootEntry.ip,
    port: rootEntry.port,
  };

  try {
    const { serverInfo, connects } = await fetchConnects(rootEntry);
    const children = [];
    for (const child of connects) {
      children.push(await buildChildNode(child, 1, depth, visited, sourcesByName));
    }
    return {
      ...rootBase,
      pid: serverInfo.pid,
      version: serverInfo.version,
      status: 'expanded',
      children,
    };
  } catch (err) {
    return {
      ...rootBase,
      status: 'unreachable',
      error: err.message || String(err),
      children: [],
    };
  }
}

// Duyệt toàn bộ cây đã build (1 lần, đệ quy mọi cấp) để tổng hợp số liệu, không
// gọi thêm request nào. Root không tính vào các tổng — chỉ tính node con.
// cycle_detected không cộng vào totalReportServer (server đó đã được đếm ở lần
// xuất hiện đầu tiên); max_depth_reached luôn là lần xuất hiện đầu tiên (nhờ thứ
// tự kiểm tra visited-trước-depth ở buildChildNode) nên được cộng vào tổng.
function computeSummary(root) {
  const summary = {
    totalReportServer: 0,
    totalCashServer: 0,
    totalManagerStation: 0,
    noConfigCount: 0,
    unreachableCount: 0,
    cycleDetectedCount: 0,
    maxDepthReachedCount: 0,
  };

  function visit(node) {
    if (!node || !node.children) return;
    for (const child of node.children) {
      switch (child.applicationKind) {
        case 'Report Server':
          if (child.status === 'cycle_detected') {
            summary.cycleDetectedCount++;
          } else {
            summary.totalReportServer++;
            if (child.status === 'no_config') summary.noConfigCount++;
            else if (child.status === 'unreachable') summary.unreachableCount++;
            else if (child.status === 'max_depth_reached') summary.maxDepthReachedCount++;
          }
          break;
        case 'Cash Server':
          summary.totalCashServer++;
          break;
        case 'Manager Station':
          summary.totalManagerStation++;
          break;
        default:
          break; // giá trị applicationKind lạ — không tính vào tổng nào
      }
      visit(child);
    }
  }

  visit(root);
  return summary;
}

module.exports = { buildTree, computeSummary, parseConnectsHtml, DEFAULT_MAX_DEPTH };
